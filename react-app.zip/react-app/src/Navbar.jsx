


function Navbar(){
    return (
        <>
        <nav>
            <h2>JeeInus</h2>
            <button>Login</button>
        </nav>
       
      </>
    );
}

export default Navbar
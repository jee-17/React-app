function Footer(){
    return(
        <footer>
            2022 rights reserved JeeInus
        </footer>
    )
}
export default Footer